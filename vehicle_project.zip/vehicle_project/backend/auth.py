from flask import Blueprint, request, jsonify, session, render_template, redirect, url_for
import sqlite3
from flask_bcrypt import Bcrypt

bcrypt = Bcrypt()
auth_bp = Blueprint('auth', __name__, template_folder='templates')

def get_db_connection():
    conn = sqlite3.connect('vehicle.db')
    conn.row_factory = sqlite3.Row
    return conn

# ---------- SIGNUP ----------
@auth_bp.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'GET':
        return render_template('signup.html')

    username = request.form.get('username')
    password = request.form.get('password')

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    conn = get_db_connection()
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return render_template('signup.html', error='Username already exists')

    conn.close()
    return redirect(url_for('auth.login'))

# ---------- LOGIN ----------
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')

    username = request.form.get('username')
    password = request.form.get('password')

    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=?", (username,))
    user = c.fetchone()
    conn.close()

    if user and bcrypt.check_password_hash(user['password'], password):
        session['user_id'] = user['id']
        session['username'] = user['username']
        return redirect(url_for('auth.home'))
    else:
        return render_template('login.html', error='Invalid username or password')

# ---------- HOME ----------
@auth_bp.route('/home')
def home():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    return render_template('home.html', username=session['username'])

# ---------- LOGOUT ----------
@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth.login'))

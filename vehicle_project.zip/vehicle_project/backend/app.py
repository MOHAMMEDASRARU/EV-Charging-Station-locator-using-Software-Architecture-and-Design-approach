from flask import Flask, render_template, request, session, redirect, jsonify
import sqlite3, datetime
import os 
app = Flask(
    __name__,
    template_folder=os.path.join(os.path.dirname(__file__), 'templates'),
    static_folder=os.path.join(os.path.dirname(__file__), 'static')
)

app.secret_key = "vehicle_secret"

def get_connection():
    conn = sqlite3.connect('vehicle.db')
    conn.row_factory = sqlite3.Row
    return conn

# ---------------- LOGIN / SIGNUP ----------------
@app.route('/')
def index():
    return redirect('/login')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_connection()
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            return redirect('/login')
        except sqlite3.IntegrityError:
            return "Username already exists"
        finally:
            conn.close()
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_connection()
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = c.fetchone()
        conn.close()

        if user:
            session['username'] = username
            return redirect('/home')
        else:
            return "Invalid username or password"
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')


# ---------------- HOME / MAP ----------------
@app.route('/home')
@app.route('/home')
def home():
    if 'username' not in session:
        return redirect('/login')

    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM charging_stations")
    stations = [dict(row) for row in c.fetchall()]  # convert Row objects to dict
    conn.close()

    return render_template('home.html', username=session['username'], stations=stations)

# ---------------- BOOK SLOT ----------------
@app.route('/book_slot', methods=['POST'])
# Book slot route (with plug count update)
@app.route('/book_slot', methods=['POST'])
@app.route('/book_slot', methods=['POST'])
def book_slot():
    if 'username' not in session:
        return jsonify({'error': 'Login required'}), 401

    data = request.get_json()
    station_name = data.get('station_name')
    time_slot = data.get('time_slot', 'Not specified')

    conn = sqlite3.connect('vehicle.db')
    c = conn.cursor()

    # Check plug availability
    c.execute("SELECT plug_count FROM charging_stations WHERE name=?", (station_name,))
    result = c.fetchone()
    if not result or result[0] <= 0:
        conn.close()
        return jsonify({'error': 'No available plugs at this station ❌'})

    # Book slot with time_slot added
    c.execute(
    "INSERT INTO bookings (username, station_name, date, status) VALUES (?, ?, ?, ?)",
    (session['username'], f"{station_name} ({time_slot})",
     datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'Booked')
)


    # Reduce plug count
    c.execute("UPDATE charging_stations SET plug_count = plug_count - 1 WHERE name=?", (station_name,))
    conn.commit()
    conn.close()

    return jsonify({'message': f'Booking confirmed for {station_name} ✅ at {time_slot}'})



    

# ---------------- VIEW BOOKINGS ----------------
@app.route('/bookings')
@app.route('/bookings')
def view_bookings():
    if 'username' not in session:
        return redirect('/login')

    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM bookings WHERE username=?", (session['username'],))
    bookings = [dict(row) for row in c.fetchall()]  # convert Row objects to dict
    conn.close()

    return render_template('bookings.html', bookings=bookings)
@app.route('/cancel_booking/<int:booking_id>', methods=['POST'])
def cancel_booking(booking_id):
    if 'username' not in session:
        return jsonify({'error': 'Login required'}), 401

    conn = sqlite3.connect('vehicle.db')
    c = conn.cursor()

    # Get booking details
    c.execute("SELECT station_name, status FROM bookings WHERE id=? AND username=?", (booking_id, session['username']))
    booking = c.fetchone()
    if not booking:
        conn.close()
        return jsonify({'error': 'Booking not found ❌'})

    station_name, status = booking
    if status == 'Cancelled':
        conn.close()
        return jsonify({'message': 'Booking already cancelled'})

    # Cancel booking
    c.execute("UPDATE bookings SET status='Cancelled' WHERE id=?", (booking_id,))
    c.execute("UPDATE charging_stations SET plug_count = plug_count + 1 WHERE name=?", (station_name,))
    conn.commit()
    conn.close()

    return jsonify({'message': f'Booking for {station_name} cancelled ✅'})


@app.route('/test')
def test():
    return render_template('test.html')


# ---------------- RUN APP ----------------
if __name__ == '__main__':
    app.run(debug=True)

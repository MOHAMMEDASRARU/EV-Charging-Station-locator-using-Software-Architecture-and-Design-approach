import sqlite3

conn = sqlite3.connect('vehicle.db')
c = conn.cursor()

# Add plug_count column if it doesn't exist
try:
    c.execute("ALTER TABLE charging_stations ADD COLUMN plug_count INTEGER DEFAULT 4")
except:
    print("Column already exists, skipping...")

# Add cancel_status column to bookings table if not there
try:
    c.execute("ALTER TABLE bookings ADD COLUMN status TEXT DEFAULT 'Booked'")
except:
    print("Status column already exists, skipping...")

conn.commit()
conn.close()

print("Database updated ✅")

from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
from database import get_connection

bookings_bp = Blueprint('bookings', __name__, url_prefix='/bookings')

# User dashboard
@bookings_bp.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    return render_template('home.html', username=session['user_name'])

# API to get all stations (used in map)
@bookings_bp.route('/api/stations')
def stations():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM stations")
    stations = [
        {"id": row[0], "name": row[1], "lat": row[2], "lng": row[3], "plugs": row[4], "rate_per_kwh": row[5]}
        for row in c.fetchall()
    ]
    conn.close()
    return jsonify(stations)

# API to book a slot
@bookings_bp.route('/api/book', methods=['POST'])
def book_slot():
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401
    data = request.get_json()
    station_id = data['station_id']
    start_time = data['start_time']
    end_time = data['end_time']
    kwh = float(data['kwh'])  # user selects units
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT rate_per_kwh FROM stations WHERE id=?", (station_id,))
    rate = c.fetchone()[0]
    cost = rate * kwh
    c.execute("INSERT INTO bookings (user_id, station_id, start_time, end_time, cost) VALUES (?, ?, ?, ?, ?)",
              (session['user_id'], station_id, start_time, end_time, cost))
    conn.commit()
    conn.close()
    return jsonify({"message": "Booking successful!", "cost": cost})

# API to fetch user's bookings
@bookings_bp.route('/api/mybookings')
def my_bookings():
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        SELECT b.id, s.name, b.start_time, b.end_time, b.cost
        FROM bookings b JOIN stations s ON b.station_id = s.id
        WHERE b.user_id=?
    """, (session['user_id'],))
    result = [
        {"id": row[0], "station": row[1], "start": row[2], "end": row[3], "cost": row[4]}
        for row in c.fetchall()
    ]
    conn.close()
    return jsonify(result)

# API to cancel booking
@bookings_bp.route('/api/cancel/<int:booking_id>', methods=['DELETE'])
def cancel_booking(booking_id):
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM bookings WHERE id=? AND user_id=?", (booking_id, session['user_id']))
    conn.commit()
    conn.close()
    return jsonify({"message": "Booking cancelled"})
# Feedback submission
@bookings_bp.route('/api/feedback', methods=['POST'])
def feedback():
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401
    data = request.get_json()
    station_id = data['station_id']
    rating = int(data['rating'])
    comment = data['comment']
    conn = get_connection()
    c = conn.cursor()
    c.execute("INSERT INTO feedback (user_id, station_id, rating, comment) VALUES (?, ?, ?, ?)",
              (session['user_id'], station_id, rating, comment))
    conn.commit()
    conn.close()
    return jsonify({"message": "Feedback submitted successfully!"})

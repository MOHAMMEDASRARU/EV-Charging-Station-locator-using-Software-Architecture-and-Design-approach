import sqlite3

conn = sqlite3.connect('vehicle.db')
c = conn.cursor()

# ---------------- Users Table ----------------
c.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT
)
''')

# ---------------- Charging Stations Table ----------------
c.execute('''
CREATE TABLE IF NOT EXISTS charging_stations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    lat REAL,
    lon REAL,
    plug_count INTEGER
)
''')

# ---------------- Bookings Table ----------------
c.execute('''
CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    station_name TEXT,
    date TEXT
)
''')

# ---------------- Sample Charging Stations ----------------
sample_stations = [
    ("Central Mall Station", 12.9716, 77.5946, 4),
    ("Tech Park Station", 12.9352, 77.6245, 6),
    ("City Center Station", 12.9833, 77.5833, 3),
    ("Airport Road Station", 12.9900, 77.5900, 5),
    ("Metro Station Station", 12.9750, 77.6100, 2)
]

# Insert sample stations
for station in sample_stations:
    c.execute("INSERT INTO charging_stations (name, lat, lon, plug_count) VALUES (?, ?, ?, ?)", station)

conn.commit()
conn.close()

print("✅ Database created and sample charging stations added!")

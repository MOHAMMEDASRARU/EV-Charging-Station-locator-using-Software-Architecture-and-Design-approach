from flask import Blueprint, render_template
from database import get_connection

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/dashboard')
def dashboard():
    conn = get_connection()
    c = conn.cursor()

    c.execute("SELECT COUNT(*) FROM users")
    total_users = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM bookings")
    total_bookings = c.fetchone()[0]

    c.execute("""
        SELECT s.name, COUNT(b.id) as count
        FROM stations s LEFT JOIN bookings b ON s.id=b.station_id
        GROUP BY s.name ORDER BY count DESC
    """)
    popular = c.fetchall()

    conn.close()
    return render_template("admin_dashboard.html",
                           total_users=total_users,
                           total_bookings=total_bookings,
                           popular=popular)

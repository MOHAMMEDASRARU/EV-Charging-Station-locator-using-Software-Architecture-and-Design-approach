package com.example.vehicleproject.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "bookings")
public class Booking {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String stationName;
    private String status;
    private LocalDateTime date;

    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}

    public String getUsername(){return username;}
    public void setUsername(String username){this.username=username;}

    public String getStationName(){return stationName;}
    public void setStationName(String stationName){this.stationName=stationName;}

    public String getStatus(){return status;}
    public void setStatus(String status){this.status=status;}

    public LocalDateTime getDate(){return date;}
    public void setDate(LocalDateTime date){this.date=date;}
}

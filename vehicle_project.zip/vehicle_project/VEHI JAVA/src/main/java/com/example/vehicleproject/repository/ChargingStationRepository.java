package com.example.vehicleproject.repository;

import com.example.vehicleproject.model.ChargingStation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChargingStationRepository extends JpaRepository<ChargingStation, Long> {
    ChargingStation findByName(String name);
}

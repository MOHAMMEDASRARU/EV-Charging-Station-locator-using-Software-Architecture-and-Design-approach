package com.example.vehicleproject.controller;

import com.example.vehicleproject.model.*;
import com.example.vehicleproject.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.*;

@Controller
public class BookingController {

    @Autowired private ChargingStationRepository stationRepo;
    @Autowired private BookingRepository bookingRepo;

    @GetMapping({"/home"})
    public String home(HttpSession session, Model model) {
        if (session.getAttribute("username") == null) return "redirect:/login";
        List<ChargingStation> stations = stationRepo.findAll();
        model.addAttribute("username", session.getAttribute("username"));
        model.addAttribute("stations", stations);
        return "home";
    }

    @PostMapping("/book_slot")
    @ResponseBody
    public ResponseEntity<?> bookSlot(@RequestBody Map<String, String> data, HttpSession session) {
        String username = (String) session.getAttribute("username"); 
        if (username == null) return ResponseEntity.status(401).body(Map.of("error","Login required"));

        String stationName = data.get("station_name"); 
        String timeSlot = data.getOrDefault("time_slot","Not specified");
        ChargingStation station = stationRepo.findByName(stationName);

        if (station == null || station.getPlugCount() <= 0) return ResponseEntity.ok(Map.of("error","No available plugs at this station ❌"));

        Booking b = new Booking();
        b.setUsername(username);
        b.setStationName(stationName + " (" + timeSlot + ")");
        b.setDate(LocalDateTime.now());
        b.setStatus("Booked");
        bookingRepo.save(b);

        station.setPlugCount(station.getPlugCount() - 1);
        stationRepo.save(station);

        return ResponseEntity.ok(Map.of("message","Booking confirmed for " + stationName + " ✅ at " + timeSlot));
    }

    @GetMapping("/bookings")
    public String viewBookings(HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/login";
        List<Booking> bookings = bookingRepo.findByUsername(username);
        model.addAttribute("bookings", bookings);
        return "bookings";
    }

    @PostMapping("/cancel_booking/{id}")
    @ResponseBody
    public ResponseEntity<?> cancelBooking(@PathVariable Long id, HttpSession session) {
        String username = (String) session.getAttribute("username"); 
        if (username == null) return ResponseEntity.status(401).body(Map.of("error","Login required"));

        Optional<Booking> opt = bookingRepo.findById(id);
        if (opt.isEmpty() || !opt.get().getUsername().equals(username)) return ResponseEntity.ok(Map.of("error","Booking not found ❌"));

        Booking b = opt.get();
        if ("Cancelled".equals(b.getStatus())) return ResponseEntity.ok(Map.of("message","Booking already cancelled"));

        b.setStatus("Cancelled"); bookingRepo.save(b);

        String originalStation = b.getStationName().split(" \\(")[0];
        ChargingStation st = stationRepo.findByName(originalStation);
        if (st != null) { st.setPlugCount(st.getPlugCount() + 1); stationRepo.save(st); }

        return ResponseEntity.ok(Map.of("message","Booking for " + b.getStationName() + " cancelled ✅"));
    }
}

package com.example.vehicleproject.model;

import jakarta.persistence.*;

@Entity
@Table(name = "charging_stations")
public class ChargingStation {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false)
    private String name;

    @Column(name="plug_count")
    private int plugCount;

    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}

    public String getName(){return name;}
    public void setName(String name){this.name=name;}

    public int getPlugCount(){return plugCount;}
    public void setPlugCount(int plugCount){this.plugCount=plugCount;}
}

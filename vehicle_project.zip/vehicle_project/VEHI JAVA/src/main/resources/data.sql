INSERT INTO charging_stations (name, plug_count) VALUES ('Station A', 3);
INSERT INTO charging_stations (name, plug_count) VALUES ('Station B', 2);
INSERT INTO charging_stations (name, plug_count) VALUES ('Station C', 5);

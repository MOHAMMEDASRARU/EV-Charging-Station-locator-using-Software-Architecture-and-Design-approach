# Vehicle Project - Java (Spring Boot) with SQLite + BCrypt

How to run:

Prerequisites: Java 17+, Maven

1. Build:
   ```bash
   mvn clean package
   ```
2. Run:
   ```bash
   mvn spring-boot:run
   ```
3. Open http://localhost:8080/

Notes:
- Passwords are stored hashed using BCrypt.
- This project uses SQLite file `vehicle.db` in the project root.
- Initial charging stations are inserted via `data.sql` on first run.
